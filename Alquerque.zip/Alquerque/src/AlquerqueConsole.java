public class AlquerqueConsole {
}
